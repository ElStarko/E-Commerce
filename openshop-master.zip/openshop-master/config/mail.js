module.exports = {
    smtp: {
        host: "",
        port: "",
        auth: {
            user: "",
            pass: ""
        }
    },
    api: {
        api_url: "",
        api_user: "",
        api_key: ""
    },
    general: {
        domain: "",
        noreply_mail: "",
        register_mail: "",
        reset_mail: "",
        verify_mail: ""
    }
};